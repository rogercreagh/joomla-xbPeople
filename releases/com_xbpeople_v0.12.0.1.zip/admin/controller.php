<?php
/*******
 * @package xbPeople
 * @filesource admin/controller.php
 * @version 0.9.0 5th April 2021
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2021
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 ******/
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

class XbpeopleController extends BaseController
{
	protected $default_view = 'dashboard';
	
	public function display ($cachable = false, $urlparms = false){
//		require_once JPATH_COMPONENT.'/helpers/xbpeople.php';
//		require_once JPATH_COMPONENT.'/helpers/xbculture.php';
		
		return parent::display();
	}
}